export default function handler(req, res) {
    res.status(200).json( [	
        22010,
        54660,
        54000,
        54810,
        54700,
        54570,
        38000  
    
    ])
  }

// s$AcD4una.zdepJ