import React from 'react'

const Sample = () => {
  return (
    <div>sample</div>
  )
}

export default Sample